sap.ui.define(["sap/fe/core/AppComponent"], function (AppComponent) {
  return AppComponent.extend("sap.capire.travels.Component", {
    metadata: { manifest: "json" },
  });
});
