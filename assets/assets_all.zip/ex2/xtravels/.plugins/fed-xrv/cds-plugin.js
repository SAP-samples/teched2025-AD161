module.exports = require ('./lib/federation-service') .bootstrap()
